import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('/content/Country-data.csv')
df = df.drop(columns=['country'])
df.head()


df.tail()
df.describe()
df.info() #to check for missing data
sns.jointplot(x='gdpp', y='income', data=df, color = 'blue')
sns.jointplot(x='income', y='gdpp', data=df, color = 'green')
sns.pairplot(df)
sns.lmplot(data = df, x='gdpp', y='income')
sns.lmplot(data = df, x='income', y='gdpp')
X = df.drop(columns=['income'])
X
y = df['income']
y
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X,y, test_size = 0.25, random_state=42)
X_train
X_test
X_train.shape
X_test.shape
y_train.shape

y_test.shape
from sklearn.linear_model import LinearRegression
regressor = LinearRegression(fit_intercept = True)
regressor.fit(X_train, y_train)
print('Linear Model Coefficient (m)', regressor.coef_)
print('Linear Model Coefficient (b)', regressor.intercept_)
y_predict = regressor.predict(X_test)
y_predict
y_test
# Sort values to avoid a broken regression line
X_train_sorted = X_train.sort_values(by='gdpp')

plt.scatter(X_train['gdpp'], y_train, color='blue')
plt.plot(
    X_train_sorted['gdpp'],
    regressor.predict(X_train_sorted),
    color='black'
)

plt.ylabel('Income')
plt.xlabel('GDP per Capita (gdpp)')
plt.title('Income vs GDP per Capita (Training Set)')
plt.show()

X_test_sorted = X_test.sort_values(by='gdpp')

plt.scatter(X_test['gdpp'], y_test, color='grey')
plt.plot(X_test_sorted['gdpp'], regressor.predict(X_test_sorted), color='red')

plt.ylabel('Income')
plt.xlabel('GDP per Capita')
plt.title('Income vs GDP per Capita (Testing Set)')
plt.show()
#health = [[2]]
#income = regressor.predict(health)
#income
new_data = pd.DataFrame([[
    130.0,   # child_mort
    25.3,    # exports
    5.07,    # health
    17.4,    # imports
    104.0,   # inflation
    60.5,    # life_expec
    5.84,    # total_fer
    2330     # gdpp
]], columns=X.columns)

income = regressor.predict(new_data)
print(income)

from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
import numpy as np

# Predict on the same X your model was trained on
y_pred = regressor.predict(X)

# R² Score (1 = perfect)
r2 = r2_score(y, y_pred)

# Mean Absolute Error
mae = mean_absolute_error(y, y_pred)

# Root Mean Squared Error
rmse = np.sqrt(mean_squared_error(y, y_pred))

print("R2 Score:", r2)
print("MAE:", mae)
print("RMSE:", rmse)

