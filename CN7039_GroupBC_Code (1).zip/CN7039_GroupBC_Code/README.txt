Prototype (D4)
Contents
*  CN7039_GroupBC_Code.py : Jupyter notebook containing the prototype code
* README.md : Instructions for running the prototype
Running the Prototype (Google Colab – Recommended)
1. Go to https://colab.research.google.com
2. Click Upload notebook
3. CN7039_GroupBC_Code.py
4. Upload the required datasets (e.g. country dataset) using:
   * The Colab file upload button, or
   * files.upload() if prompted in the notebook
5. Ensure dataset file names match those referenced in the notebook
6. Run all cells from top to bottom
Running Locally (Optional)
1. Ensure Python is installed
2. Open CN7039_GroupBC_Code.py in Jupyter Notebook or JupyterLab
3. Place the dataset files in the same directory as the notebook
4. Run all cells in order
Notes
* The notebook contains all code required for the prototype
* No additional configuration is required beyond uploading the datasets